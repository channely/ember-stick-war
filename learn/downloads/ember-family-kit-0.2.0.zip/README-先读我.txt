亲子游戏工坊 · 0.2.0

1. 将 ZIP 完整解压到一个新文件夹。
2. 双击 index.html，选择今天的课程。也可以直接打开 examples 中的 HTML 文件。
3. 第一课可以只用纸、笔与豆子。每次约 20–30 分钟，可拆开完成。
4. 阅读 parent-child-guide-0.2.0.pdf，包含从空白文件开始的 9 行代码、12 次课程和第一课脚本。
5. 家长用记事本或代码编辑器打开示例 HTML，孩子决定修改哪一个数字。保存，回浏览器刷新。
6. 保存为新文件，保留上一份能运行的版本。不要用 Word 编辑代码。
7. cards.html 或 designer-cards-0.2.0.pdf 可打印规则卡、关卡卡、测试卡与日记。

每个示例都可以离线运行，不需要安装 Node.js 或 Python。
这是教学用精简作品。正式版游戏的完整源码与版本说明：
https://ember-stick-war.channely.chatgpt.site/release/
在线游戏和工坊： https://ember-stick-war.channely.chatgpt.site/

孩子负责预测、设计、画图、试玩和解释，家长负责设备、打字协助、保存与账号。
